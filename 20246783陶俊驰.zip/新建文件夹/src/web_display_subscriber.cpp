#include <rclcpp/rclcpp.hpp>
#include <my_camera_project/msg/image_data.hpp>
#include <sys/mman.h>
#include <semaphore.h>
#include <thread>
#include "http_server.hpp"  // 假设有一个简单的HTTP服务器库

class WebDisplaySubscriber : public rclcpp::Node
{
public:
    WebDisplaySubscriber() : Node("web_display_subscriber")
    {
        subscriber_ = this->create_subscription<my_camera_project::msg::ImageData>(
            "camera_image", 10, std::bind(&WebDisplaySubscriber::image_callback, this, std::placeholders::_1));

        // 创建信号量（同步使用）
        sem_init(&sem_, 1, 1);

        // 启动HTTP流服务器
        server_thread_ = std::thread([this](){ run_http_server(); });
    }

    ~WebDisplaySubscriber()
    {
        server_thread_.join();
        sem_destroy(&sem_);
    }

private:
    void image_callback(const my_camera_project::msg::ImageData::SharedPtr msg)
    {
        // 从共享内存读取图像数据
        sem_wait(&sem_);  // 锁定信号量
        int shm_fd = shm_open(msg->shm_id.c_str(), O_RDWR, 0666);
        uint8_t* image_data = static_cast<uint8_t*>(mmap(NULL, msg->width * msg->height * 3 / 2,
                                                          PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0));

        // 将NV12转换为MJPEG（需要自己实现转换）
        // 转换代码省略...

        sem_post(&sem_);  // 解锁信号量

        // 将转换后的MJPEG推送到视频流
        video_stream_server_.push_frame(image_data);
    }

    void run_http_server()
    {
        // 启动一个HTTP服务器，使用80端口发布视频流
        HttpServer server(8000);
        server.start();
    }

    rclcpp::Subscription<my_camera_project::msg::ImageData>::SharedPtr subscriber_;
    std::thread server_thread_;
    sem_t sem_;
    VideoStreamServer video_stream_server_;  // 自己实现的MJPEG流服务器类
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<WebDisplaySubscriber>());
    rclcpp::shutdown();
    return 0;
}