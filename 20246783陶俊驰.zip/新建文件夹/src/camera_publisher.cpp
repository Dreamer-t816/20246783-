#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/string.hpp>
#include <fcntl.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <linux/videodev2.h>
#include <cstring>
#include <chrono>
#include "my_camera_project/msg/image_data.hpp"

class CameraPublisher : public rclcpp::Node
{
public:
    CameraPublisher() : Node("camera_publisher")
    {
        publisher_ = this->create_publisher<my_camera_project::msg::ImageData>("camera_image", 10);
        
        // 打开V4L2设备
        camera_fd_ = open("/dev/video0", O_RDWR);
        if (camera_fd_ == -1) {
            RCLCPP_ERROR(this->get_logger(), "Failed to open V4L2 device");
            return;
        }

        // 配置摄像头
        v4l2_format_ = {};
        v4l2_format_.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        v4l2_format_.fmt.pix.width = 1920;  // 假设分辨率是1920x1080
        v4l2_format_.fmt.pix.height = 1080;
        v4l2_format_.fmt.pix.pixelformat = V4L2_PIX_FMT_NV12; // NV12格式
        if (ioctl(camera_fd_, VIDIOC_S_FMT, &v4l2_format_) == -1) {
            RCLCPP_ERROR(this->get_logger(), "Failed to set V4L2 format");
            return;
        }

        // 创建共享内存
        shm_fd_ = shm_open("/camera_shm", O_CREAT | O_RDWR, 0666);
        ftruncate(shm_fd_, v4l2_format_.fmt.pix.width * v4l2_format_.fmt.pix.height * 3 / 2); // NV12大小
        image_data_ = static_cast<uint8_t*>(mmap(NULL, v4l2_format_.fmt.pix.width * v4l2_format_.fmt.pix.height * 3 / 2,
                                                 PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd_, 0));

        // 创建信号量（同步使用）
        sem_init(&sem_, 1, 1);

        // 定时发布图像数据
        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(33), std::bind(&CameraPublisher::timer_callback, this));
    }

    ~CameraPublisher()
    {
        // 清理资源
        close(camera_fd_);
        close(shm_fd_);
        sem_destroy(&sem_);
    }

private:
    void timer_callback()
    {
        // 读取图像数据到共享内存
        sem_wait(&sem_);  // 锁定信号量
        if (read(camera_fd_, image_data_, v4l2_format_.fmt.pix.width * v4l2_format_.fmt.pix.height * 3 / 2) == -1) {
            RCLCPP_ERROR(this->get_logger(), "Failed to read image from V4L2 device");
        }
        sem_post(&sem_);  // 解锁信号量

        // 创建并发布消息
        auto message = my_camera_project::msg::ImageData();
        message.shm_id = "/camera_shm";
        message.width = v4l2_format_.fmt.pix.width;
        message.height = v4l2_format_.fmt.pix.height;
        message.encoding = "NV12";
        message.timestamp = this->get_clock()->now();
        publisher_->publish(message);
    }

    int camera_fd_;
    int shm_fd_;
    uint8_t* image_data_;
    v4l2_format v4l2_format_;
    rclcpp::Publisher<my_camera_project::msg::ImageData>::SharedPtr publisher_;
    rclcpp::TimerBase::SharedPtr timer_;
    sem_t sem_;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<CameraPublisher>());
    rclcpp::shutdown();
    return 0;
}